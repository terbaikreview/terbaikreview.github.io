<!--t Parfum SummerScent t-->
<!--d Parfum EAU DE TOILETTE (EDT) SummerScent merupakan seri parfum berbagai aroma yang menyegarkan. d-->

Parfum EAU DE TOILETTE (EDT) SummerScent merupakan seri parfum berbagai aroma yang menyegarkan.