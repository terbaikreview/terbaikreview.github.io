<!--t Parfum SummerScent YERVANT t-->
<!--d Aroma manly yang kuat dengan Woody Aroma, seperti aroma hutan Pinus. Perpaduan segar dari aroma Benzoin, Woodsy, dan Haitian Vetiver pada base note. d-->
<!--tag parfum eau de toilette,parfum edt,summerscent,yervant tag-->
<!--image https://universolaromas.com/wp-content/uploads/2021/11/yervant-parfum-eau-de-toilette.webp image-->

Aroma manly yang kuat dengan Woody Aroma, seperti aroma hutan Pinus. Perpaduan segar dari aroma Benzoin, Woodsy, dan Haitian Vetiver pada base note. Sedangkan di fase tengah kamu akan menemukan amber, freesia, dan Guatemalan cardamom. Pada aroma puncak ada Calabrian bergamot, cactus juice, dan pink grapefruit  