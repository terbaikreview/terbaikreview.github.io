<!--t Parfum SummerScent GODFREY t-->
<!--d Keharuman yang ringan yang berasal dari perpaduan Ambergris dan Cedar Wood di semprotan pertama. Setelah beberapa saat, wanginya langsung berubah d-->
<!--tag godfrey,summerscent tag-->
<!--image https://universolaromas.com/wp-content/uploads/2021/11/godfrey-parfum-eau-de-toilette.webp image-->

Keharuman yang ringan yang berasal dari perpaduan Ambergris dan Cedar Wood di semprotan pertama. Setelah beberapa saat, wanginya langsung berubah agak fresh dan meninggalkan aroma floral yang berasal dari jasmine. 